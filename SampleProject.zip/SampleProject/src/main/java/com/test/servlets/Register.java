package com.test.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class Register extends HttpServlet{
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String htmlResponse="<h1>Aspire Payroll System App</h1>";
		PrintWriter out=resp.getWriter();
		resp.setContentType("text/html");
		out.println("<html><body>");
		ApplicationDao dao=new ApplicationDao();
		String result=dao.getString();
		out.println(htmlResponse+result+"</body></html>");
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username=req.getParameter("newusername");
		String password=req.getParameter("newpassword");
		User user=new User(username,password);
		ApplicationDao dao=new ApplicationDao();
		int rows=dao.registerUser(user);
		String message=null;
		if(rows!=0)
			message="Successfull application.";
		else
			message="Failed to insert.";
	}
}
