package com.test.servlets;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

	public static Connection getConnectionToDatabase() {
		Connection connectionToDatabase=null;
		
		try {
			String user = "root";
			String password = "aspire@123";
			String url = "jdbc:mysql://localhost:3306/Users";
			Class.forName("com.mysql.jdbc.Driver");
			connectionToDatabase= DriverManager.getConnection(url, user, password);
		}
		catch(ClassNotFoundException classNotFoundException) {
			classNotFoundException.printStackTrace();
		}
		catch (SQLException sqlException) {
			sqlException.printStackTrace();
		}
		
		if(connectionToDatabase!=null)
			System.out.println("Connected to database.");
		
		return connectionToDatabase;
		
	}
}
