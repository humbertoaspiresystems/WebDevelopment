package com.test.servlets;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
// 
public class ApplicationDao {

	public String getString() {
		String data="";
		try {
			String query="SELECT * FROM Users";
			Connection connection=DBConnection.getConnectionToDatabase();
			Statement statement=connection.createStatement();
			ResultSet set=statement.executeQuery(query);
			while (set.next()) {
				for (int databaseRowCounter = 1; databaseRowCounter < 3; databaseRowCounter++) {
					data += set.getString(databaseRowCounter) + "\t";
				}
			}
		}
		catch(SQLException sqlException) {
			sqlException.printStackTrace();
		}
		return data;
	}
	
	public int registerUser(User user) {
		int rowsAffected=0;
		try {
			Connection connectionToDatabase=DBConnection.getConnectionToDatabase();
			String query="INSERT IGNORE INTO Users VALUE('"+user.getUsername()+"','"+user.getPassword()+"')";
			PreparedStatement statement=connectionToDatabase.prepareStatement(query);
			rowsAffected=statement.executeUpdate();
		} 
		catch (SQLException sqlException) {
			sqlException.printStackTrace();
		}
		return rowsAffected;
	}
	
	public boolean validateUser(String username, String password) {
		Connection connection = DBConnection.getConnectionToDatabase();
		String query = "SELECT * FROM USERS WHERE User_Name='"+username+"' AND Password='"+password+"'";
		PreparedStatement statement;
		boolean isValidUser = false;
		try {
			statement = connection.prepareStatement(query);
			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				isValidUser = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return isValidUser;

	}
}
